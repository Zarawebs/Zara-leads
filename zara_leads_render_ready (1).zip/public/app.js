const $ = (id) => document.getElementById(id);
let currentLeads = [];
let currentView = "search";

async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function esc(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
}
function card(lead) {
  const website = lead.website ? `<a class="small-btn" href="${esc(lead.website)}" target="_blank" rel="noopener">Open website ↗</a>` : `<span class="small-btn muted">No website listed</span>`;
  return `<article class="lead">
    <span class="tag">${lead.website ? "WEBSITE LISTED" : "NO WEBSITE LISTED"}</span>
    <h3>${esc(lead.name)}</h3><p>⌖ ${esc(lead.address || "Address not provided")}</p>
    <div class="lead-actions">${website}
      ${lead.mapsUrl ? `<a class="small-btn muted" href="${esc(lead.mapsUrl)}" target="_blank" rel="noopener">Google Maps ↗</a>` : ""}
      ${lead.saved ? `<button class="small-btn muted" data-remove="${esc(lead.id)}">Remove saved</button>` : `<button class="small-btn" data-save="${esc(lead.id)}">☆ Save lead</button>`}
      ${lead.contacted ? `<span class="small-btn muted">Contacted ✓</span>` : `<button class="small-btn muted" data-contact="${esc(lead.id)}">Mark contacted</button>`}
    </div></article>`;
}
function renderLeads(target, leads) {
  $(target).innerHTML = leads.length ? leads.map(card).join("") : `<div class="message">No leads to show yet.</div>`;
}
async function search() {
  const btn = $("searchBtn");
  btn.disabled = true; btn.textContent = "Searching…";
  $("message").textContent = "Searching Google Places…";
  $("leadGrid").innerHTML = "";
  try {
    const data = await api("/api/search", { method: "POST", body: JSON.stringify({
      keyword: $("keyword").value, location: $("location").value, websiteFilter: $("websiteFilter").value
    }) });
    currentLeads = data.leads || [];
    $("resultCount").textContent = `${currentLeads.length} RESULTS`;
    $("message").textContent = currentLeads.length ? "" : "No matching businesses found. Try a broader category or another location.";
    renderLeads("leadGrid", currentLeads);
  } catch (err) {
    $("message").textContent = err.message;
  } finally { btn.disabled = false; btn.innerHTML = 'Search leads <span>→</span>'; }
}
async function showSaved() {
  try {
    const data = await api("/api/saved");
    const leads = data.leads || [];
    $("savedCount").textContent = `${leads.length} SAVED`;
    renderLeads("savedGrid", leads);
  } catch (err) { $("savedGrid").innerHTML = `<p class="message">${esc(err.message)}</p>`; }
}
async function handleAction(event) {
  const b = event.target.closest("button");
  if (!b) return;
  try {
    if (b.dataset.save) {
      const lead = currentLeads.find(x => x.id === b.dataset.save);
      if (lead) await api("/api/saved", { method: "POST", body: JSON.stringify(lead) });
    } else if (b.dataset.remove) {
      await api(`/api/saved/${encodeURIComponent(b.dataset.remove)}`, { method: "DELETE" });
    } else if (b.dataset.contact) {
      await api(`/api/contacted/${encodeURIComponent(b.dataset.contact)}`, { method: "POST" });
    } else return;
    if (currentView === "saved") await showSaved(); else await search();
  } catch (err) { alert(err.message); }
}
document.querySelectorAll(".nav").forEach(btn => btn.addEventListener("click", () => {
  currentView = btn.dataset.view;
  document.querySelectorAll(".nav").forEach(x => x.classList.toggle("active", x === btn));
  const saved = currentView === "saved";
  $("searchIntro").hidden = saved; $("searchPanel").hidden = saved;
  $("apiNotice").hidden = saved; $("resultsTitle").parentElement.parentElement.hidden = saved;
  $("message").hidden = saved; $("leadGrid").hidden = saved; $("savedView").hidden = !saved;
  $("pageTitle").textContent = saved ? "Your saved prospects." : "Find your next client.";
  if (saved) showSaved();
}));
$("searchBtn").addEventListener("click", search);
$("leadGrid").addEventListener("click", handleAction);
$("savedGrid").addEventListener("click", handleAction);
$("location").addEventListener("keydown", e => { if (e.key === "Enter") search(); });
$("year").textContent = new Date().getFullYear();
api("/api/config").then(c => { if (c.apiReady) $("apiNotice").classList.remove("show"); else $("apiNotice").classList.add("show"); }).catch(() => $("apiNotice").classList.add("show"));